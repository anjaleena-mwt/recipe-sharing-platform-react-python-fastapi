import React, { useEffect, useState } from "react";

export default function AdminViewRecipes() {
  // to store recipes from backend
  const [recipes, setRecipes] = useState([]);

  // to show loading message
  const [loading, setLoading] = useState(true);

  // Fetch recipes when component loads
  useEffect(() => {
    fetch("http://127.0.0.1:8000/admin/view-recipes")
      .then(response => response.json()) // convert response to JSON
      .then(data => {
        if (Array.isArray(data)) {
          setRecipes(data); // store recipes
        } else {
          setRecipes([]); // if data is not an array, store empty array
        }
      })
      .catch(() => setRecipes([])) // in case of error
      .finally(() => setLoading(false)); // stop loading
  }, []);

  // Show loading message
  if (loading) return <p>Loading recipes...</p>;

  // Show message if no recipes found
  if (recipes.length === 0) return <p>No recipes found.</p>;

  // Render list of recipes
  return (
    <div style={{ padding: "20px" }}>
      <h2>All Recipes</h2>
      <ul>
        {recipes.map(recipe => (
          <li key={recipe.id}>
            <b>{recipe.title}</b> - {recipe.approved ? "Approved" : "Pending"} (User ID: {recipe.user_id}, Category ID: {recipe.category_id})
          </li>
        ))}
      </ul>
    </div>
  );
}
