import React, { useState, useEffect } from "react";

export default function AdminApproveRejectRecipes() {
  // State to store pending recipes
  const [recipes, setRecipes] = useState([]);

  // State to show loading message
  const [loading, setLoading] = useState(true);

  // Function to get pending recipes from backend
  const fetchPendingRecipes = () => {
    fetch("http://127.0.0.1:8000/admin/view-recipes")
      .then(response => response.json()) // convert response to JSON
      .then(data => {
        // Keep only recipes that are not approved
        if (Array.isArray(data)) {
          const pending = data.filter(recipe => !recipe.approved);
          setRecipes(pending);
        } else {
          setRecipes([]);
        }
      })
      .catch(() => setRecipes([])) // in case of error
      .finally(() => setLoading(false)); // stop loading
  };

  // Run fetchPendingRecipes when component loads
  useEffect(() => {
    fetchPendingRecipes();
  }, []);

  // Function to approve or reject a recipe
  const handleAction = (id, approve) => {
    fetch("http://127.0.0.1:8000/admin/approve-reject", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ recipe_id: id, approve })
    })
    .then(response => response.json())
    .then(() => fetchPendingRecipes()) // refresh list after action
    .catch(error => console.error(error));
  };

  // Show loading message while fetching data
  if (loading) return <p>Loading pending recipes...</p>;

  // Show message if no pending recipes
  if (recipes.length === 0) return <p>No pending recipes to approve/reject.</p>;

  // Render list of pending recipes with approve/reject buttons
  return (
    <div style={{ padding: "20px" }}>
      <h2>Approve/Reject Recipes</h2>
      <ul>
        {recipes.map(recipe => (
          <li key={recipe.id} style={{ marginBottom: "10px" }}>
            <b>{recipe.title}</b> (User ID: {recipe.user_id}, Category ID: {recipe.category_id})
            <button 
              onClick={() => handleAction(recipe.id, true)} 
              style={{ margin: "0 5px", padding: "5px 10px" }}
            >
              Approve
            </button>
            <button 
              onClick={() => handleAction(recipe.id, false)} 
              style={{ margin: "0 5px", padding: "5px 10px" }}
            >
              Reject
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
