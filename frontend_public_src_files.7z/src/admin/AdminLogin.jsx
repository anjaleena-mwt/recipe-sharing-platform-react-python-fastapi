import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function AdminLogin() {
  const navigate = useNavigate(); 

  useEffect(() => {
    
    const adminUser = {
      username: "admin",
      user_id: "admin",
      user_email: "admin@gmail.com",
      is_admin: true
    };
    localStorage.setItem("user", JSON.stringify(adminUser));

    navigate("/admin");
  }, [navigate]);

  return (
    <div >
      <h2>Logging in as Admin...</h2>
    </div>
  );
}
