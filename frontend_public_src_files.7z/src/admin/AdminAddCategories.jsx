import React, { useState, useEffect } from "react";

export default function AdminAddCategories() {
  // State for the category name input
  const [name, setName] = useState("");

  // State for showing messages
  const [message, setMessage] = useState("");

  // to store categories from backend
  const [categories, setCategories] = useState([]);

  // Function to get existing categories from backend
  const fetchCategories = () => {
    fetch("http://127.0.0.1:8000/admin/categories")
      .then(response => response.json())
      .then(data => setCategories(data)) // store categories
      .catch(error => setCategories([])); // in case of error
  };

  // Run fetchCategories when component loads
  useEffect(() => {
    fetchCategories();
  }, []);

  // Function to add a new category
  const handleAdd = () => {
    if (!name.trim()) return; // don't add empty name

    fetch("http://127.0.0.1:8000/admin/add-category", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name })
    })
    .then(response => response.json())
    .then(data => {
      setMessage(data.message || "Category added"); // show message
      setName(""); // clear input
      fetchCategories(); // refresh category list
    })
    .catch(error => setMessage("Failed to add category")); // error handling
  };

  return (
    <div style={{ padding: "20px", maxWidth: 400, margin: "0 auto" }}>
      <h2>Add Category</h2>

      {/* Input for category name */}
      <input 
        type="text" 
        value={name} 
        onChange={e => setName(e.target.value)} 
        placeholder="Category name" 
        style={{ width: "100%", padding: 8, marginBottom: 8 }}
      />

      {/* Button to add category */}
      <button onClick={handleAdd} style={{ padding: "8px 12px" }}>
        Add
      </button>

      {/* Message display */}
      {message && <p>{message}</p>}

      <h3>Existing Categories</h3>
      <ul>
        {/* Show list of categories */}
        {categories.map(c => (
          <li key={c.id}>{c.name}</li>
        ))}
      </ul>
    </div>
  );
}
