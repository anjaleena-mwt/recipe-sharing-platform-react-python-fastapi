import React from "react";
import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h3>Admin Dashboard</h3>

      <div style={{ marginTop: "30px" }}>
        <button 
          onClick={() => navigate("/admin/view-recipes")} 
          style={{ margin: "10px", padding: "10px 20px" }}
        >
          View Recipes
        </button>

        <button 
          onClick={() => navigate("/admin/approve-reject")}
          style={{ margin: "10px", padding: "10px 20px" }}
        >
          Approve/Reject Recipes
        </button>

        <button 
          onClick={() => navigate("/admin/add-categories")} 
          style={{ margin: "10px", padding: "10px 20px" }}
        >
          Add Categories
        </button>
      </div>
    </div>
  );
}
