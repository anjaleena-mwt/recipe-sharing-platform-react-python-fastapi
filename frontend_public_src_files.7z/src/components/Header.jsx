// src/user/Header.jsx
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../css/Header.css";

export default function Header() {
  const navigate = useNavigate();

  // Simple user read from localStorage
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem("user");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });

  // Update user if other tabs change localStorage or when window focuses
  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === "user") {
        try {
          setUser(e.newValue ? JSON.parse(e.newValue) : null);
        } catch {
          setUser(null);
        }
      }
    };
    const onFocus = () => {
      try {
        const raw = localStorage.getItem("user");
        setUser(raw ? JSON.parse(raw) : null);
      } catch {
        setUser(null);
      }
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener("focus", onFocus);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  // Search state
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);

  // Load categories once on mount
  useEffect(() => {
    fetch("http://127.0.0.1:8000/admin/categories")
      .then((r) => r.json())
      .then((data) => setCategories(Array.isArray(data) ? data : []))
      .catch(() => setCategories([]));
  }, []);

  // Simple debounce for autocomplete: wait 300ms after user stops typing
  useEffect(() => {
    if (!query || query.trim().length < 2) {
      setSuggestions([]);
      return;
    }

    let cancelled = false;
    const timer = setTimeout(() => {
      fetch(
        `http://127.0.0.1:8000/recipes/autocomplete?q=${encodeURIComponent(
          query.trim()
        )}`
      )
        .then((r) => {
          if (!r.ok) throw new Error("Autocomplete fetch failed");
          return r.json();
        })
        .then((data) => {
          if (!cancelled) setSuggestions(Array.isArray(data) ? data : []);
        })
        .catch(() => {
          if (!cancelled) setSuggestions([]);
        });
    }, 300);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  // Navigate to home with query params
  const onSearch = () => {
    const params = new URLSearchParams();
    if (selectedCategory) params.set("category", selectedCategory);
    if (query.trim()) params.set("q", query.trim());
    navigate("/" + (params.toString() ? `?${params.toString()}` : ""));
  };

  const searchDisabled = !selectedCategory && !query.trim();

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          <span className="text-pink">Recipe</span>
          <span className="text-black">Realm</span>
        </Link>

        {/* Toggler for small screens (Bootstrap expects this button) */}
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto cinzel-font">
            <li className="nav-item active">
              <Link className="nav-link" to="/about">
                About
              </Link>
            </li>
            <li className="nav-item active">
              <Link className="nav-link" to="/create-recipe">
                Create Recipe
              </Link>
            </li>
          </ul>

          {/* Search controls: category, input, suggestions, search button */}
          <div className="header-search d-flex align-items-center">
            <select
              className="header-select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            <input
              className="header-search-input"
              type="text"
              placeholder="Search recipes..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  if (!searchDisabled) onSearch();
                }
              }}
            />

            {/* Simple suggestion list below the input */}
            {suggestions.length > 0 && (
              <ul className="autocomplete-list">
                {suggestions.map((s) => (
                  <li
                    key={s.id}
                    onClick={() => {
                      setQuery(s.title);
                      setSuggestions([]);
                      const params = new URLSearchParams();
                      if (selectedCategory) params.set("category", selectedCategory);
                      params.set("q", s.title);
                      navigate("/?" + params.toString());
                    }}
                  >
                    {s.title}
                  </li>
                ))}
              </ul>
            )}

            <button
              onClick={onSearch}
              className="header-search-btn"
              disabled={searchDisabled}
            >
              Search
            </button>
          </div>

          {/* Profile / Login icon */}
          <div className="icons d-flex align-items-center ml-3">
            {user ? (
              <Link to="/profile" className="nav-icon mx-2" title="Profile">
                <i className="fa-solid fa-user"></i>
              </Link>
            ) : (
              <Link to="/login" className="nav-icon mx-2" title="Login">
                <i className="fa-solid fa-right-to-bracket"></i>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
