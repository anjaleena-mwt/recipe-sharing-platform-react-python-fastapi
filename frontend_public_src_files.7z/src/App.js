import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Header from './components/Header';


import About from './user/About';
import HomeRecipe from './user/HomeRecipe';
import Login from './user/Login';
import Register from './user/Register';
import Profile from './user/Profile';
import CreateRecipe from './user/CreateRecipe';
import RecipeDetails from "./user/RecipeDetails";


import AdminLogin from "./admin/AdminLogin"
import AdminDashboard from "./admin/AdminDashboard";
import AdminViewRecipes from "./admin/AdminViewRecipes";
import AdminApproveRejectRecipes from "./admin/AdminApproveRejectRecipes";
import AdminAddCategories from "./admin/AdminAddCategories";


function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<HomeRecipe />} />
        <Route path="/about" element={<About />} />

        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/admin" element={<AdminDashboard />} /> 
        <Route path="/admin/view-recipes" element={<AdminViewRecipes />} /> 
        <Route path="/admin/approve-reject" element={<AdminApproveRejectRecipes />} /> 
        <Route path="/admin/add-categories" element={<AdminAddCategories />} />

        <Route path="/profile" element={<Profile/>} />
        <Route path="/create-recipe" element={<CreateRecipe />} />
        <Route path="/recipes/:id" element={<RecipeDetails />} />


      </Routes>
    </Router>
  );
}

export default App;
