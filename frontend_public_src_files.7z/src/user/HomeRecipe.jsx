import React, { useEffect, useState, useCallback } from "react";
import RecipeCard from "./RecipeCard";
import "../css/Home.css";
import { useLocation } from "react-router-dom";

export default function HomeRecipe() {
  const location = useLocation();

  const [recipes, setRecipes] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [query, setQuery] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const [searchWarning, setSearchWarning] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchApprovedRecipes = useCallback(() => {
    setLoading(true);
    fetch("http://127.0.0.1:8000/recipes")
      .then((res) => res.json())
      .then((data) => {
        setRecipes(Array.isArray(data) ? data : []);
        setHasSearched(false);
        setSearchWarning("");
      })
      .catch(() => setRecipes([]))
      .finally(() => setLoading(false));
  }, []);

  const handleSearch = useCallback((catArg, qArg) => {
    const cat = typeof catArg === "string" ? catArg : selectedCategory;
    const q = typeof qArg === "string" ? qArg : query;

    if (!cat && !q.trim()) {
      setSearchWarning("Please choose a category or type a recipe name first.");
      setHasSearched(false);
      setRecipes([]);
      return;
    }

    setSearchWarning("");
    setHasSearched(true);
    setLoading(true);

    let url = "http://127.0.0.1:8000/recipes";
    const params = [];
    if (cat) params.push(`category=${cat}`);
    if (q.trim()) params.push(`q=${encodeURIComponent(q.trim())}`);
    if (params.length) url += "?" + params.join("&");

    fetch(url)
      .then((response) => response.json())
      .then((data) => setRecipes(Array.isArray(data) ? data : []))
      .catch(() => setRecipes([]))
      .finally(() => setLoading(false));
  }, [selectedCategory, query]);

  useEffect(() => {
    fetchApprovedRecipes();
  }, [fetchApprovedRecipes]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const cat = params.get("category") || "";
    const q = params.get("q") || "";

    setSelectedCategory(cat);
    setQuery(q);

    if (cat || q) {
      handleSearch(cat, q);
    } else {
      fetchApprovedRecipes();
    }
  }, [location.search, fetchApprovedRecipes, handleSearch]); // ✅ no warning now

  useEffect(() => {
    const onFocus = () => {
      const params = new URLSearchParams(location.search);
      if (!params.get("category") && !params.get("q")) {
        fetchApprovedRecipes();
      }
    };
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [fetchApprovedRecipes, location.search]);

  return (
    <div className="home-container">
      <div className="home-inner">
        {loading && <p style={{ textAlign: "center" }}>Loading...</p>}

        {searchWarning && (
          <p style={{ color: "#b94a48", textAlign: "center", marginTop: 12 }}>
            {searchWarning}
          </p>
        )}

        {hasSearched && recipes.length === 0 ? (
          <p className="no-recipes">No recipes found.</p>
        ) : (
          recipes.length > 0 && (
            <div className="recipes-grid">
              {recipes.map((recipe) => (
                <div className="recipe-card-wrap" key={recipe.id}>
                  <RecipeCard recipe={recipe} />
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
}
