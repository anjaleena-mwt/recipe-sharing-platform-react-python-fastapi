import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../css/Profile.css";

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const raw = localStorage.getItem("user");
    console.log("Profile mount - raw localStorage.user:", raw);

    if (!raw) {
      navigate("/login");
      return;
    }

    try {
      const parsed = JSON.parse(raw);
      const hasEmail = !!parsed.user_email;
      const hasUsername = !!parsed.username;
      const hasId = !!parsed.user_id || !!parsed.id;

      if (!hasEmail && !hasUsername && !hasId) {
        console.warn("localStorage.user missing expected fields:", parsed);
        localStorage.removeItem("user");
        navigate("/login");
        return;
      }

      setUser(parsed);
    } catch (err) {
      console.error("Failed to parse localStorage.user:", err);
      localStorage.removeItem("user");
      navigate("/login");
    }
  }, [navigate]);

  if (!user) return null;

  return (
    <div className="profile-page">
      <div className="profile-card">
        <div className="avatar">
          <div className="avatar-circle">
            {(user.username || user.user_email || "U")[0].toUpperCase()}
          </div>
        </div>

        <div className="profile-info">
          <h2>{user.username ?? user.user_email ?? "User"}</h2>
          <p><strong>Email:</strong> {user.user_email ?? "Not provided"}</p>
          <p><strong>Phone Number:</strong> {user.phone_number ?? "Not provided"}</p>
          <p><strong>Address:</strong> {user.address ?? "Not provided"}</p>

          <div className="profile-actions">
            <button
              className="btn btn-logout"
              onClick={() => {
                localStorage.removeItem("user");
                navigate("/login");
              }}
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
