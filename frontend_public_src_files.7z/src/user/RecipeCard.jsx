import React from "react";
import { Link } from "react-router-dom";
import "../css/RecipeCard.css";

export default function RecipeCard({ recipe }) {
  const imgSrc = recipe.image_url ? `http://127.0.0.1:8000${recipe.image_url}` : null;

  // small fallback excerpt from methods or ingredients
  const excerpt = (recipe.methods || recipe.ingredients || "")
    .replace(/\n+/g, " ")
    .slice(0, 140)
    .trim();

  return (
    <div className="recipe-card" role="article" aria-label={recipe.title}>
      {imgSrc ? (
        <div className="card-hero" aria-hidden={false}>
          <img src={imgSrc} alt={recipe.title} />
          <div className="card-title">{recipe.title}</div>
        </div>
      ) : (
        // fallback header when no image
        <div className="card-hero" style={{background: "#efe9e6"}}>
          <div className="card-title" style={{color:"#222"}}>{recipe.title}</div>
        </div>
      )}

      <div className="card-body">
        <div className="card-meta">
          <div className="meta-left">
            {/* username chip (if available) */}
            {recipe.username ? (
              <div className="user-chip" title={`By ${recipe.username}`}>
                {/* small avatar circle from initials */}
                <span style={{
                  width: 28, height: 28, borderRadius: 999, background: "#fff",
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                  fontWeight: 800, color: "#6b2e9b", boxShadow: "0 2px 6px rgba(107,46,155,0.12)"
                }}>
                  {recipe.username.split(" ").map(s => s[0]?.toUpperCase()).slice(0,2).join("")}
                </span>
                <span style={{marginLeft: 6}}>{recipe.username}</span>
              </div>
            ) : null}

            {/* category pill */}
            {recipe.category_name ? (
              <div className="cat-pill" style={{marginLeft: recipe.username ? 8 : 0}}>
                {recipe.category_name}
              </div>
            ) : null}
          </div>

          {/* small approval badge */}
          <div style={{fontSize: 0.85+"rem", color: recipe.approved ? "#2a7a2a" : "#8a2b2b"}}>
            {recipe.approved ? "Approved" : "Pending"}
          </div>
        </div>

        {/* short description */}
        {excerpt ? <div className="short-desc">{excerpt}...</div> : null}

        <div className="card-actions">
          <Link to={`/recipes/${recipe.id}`} className="view-btn" aria-label={`View ${recipe.title}`}>
            {/* small SVG eye icon */}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 5C7 5 3.1 8.1 1.5 12c1.6 3.9 5.5 7 10.5 7s8.9-3.1 10.5-7C20.9 8.1 17 5 12 5z" fill="white" opacity="0.18"/>
              <path d="M12 9.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5z" fill="white"/>
            </svg>
            View
          </Link>

          {/* small quick actions area (share/like etc) can go here */}
          <div style={{display:"flex", gap:8, alignItems:"center"}}>
            <button title="Like" style={{
              border:"none", background:"transparent", cursor:"pointer", fontSize:18, opacity:0.9
            }}>❤</button>
            <button title="Save" style={{
              border:"none", background:"transparent", cursor:"pointer", fontSize:18, opacity:0.85
            }}>🔖</button>
          </div>
        </div>
      </div>
    </div>
  );
}
