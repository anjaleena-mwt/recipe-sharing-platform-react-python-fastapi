// src/user/CreateRecipe.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../css/CreateRecipe.css";

export default function CreateRecipe() {
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user") || "null");
  useEffect(() => {
    if (!user) navigate("/login");
  }, [user, navigate]);

  const [title, setTitle] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [methods, setMethods] = useState("");
  const [youtube, setYoutube] = useState("");
  const [category, setCategory] = useState("");
  const [categories, setCategories] = useState([]);
  const [imageFile, setImageFile] = useState(null);

  const [error, setError] = useState("");   // always keep string
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/admin/categories")
      .then((r) => r.json())
      .then((data) => setCategories(Array.isArray(data) ? data : []))
      .catch(() => setCategories([]));
  }, []);

  const readableError = (json) => {
    // FastAPI validation errors are often in json.detail (list of errors)
    try {
      if (!json) return "Unknown error";
      if (typeof json === "string") return json;
      if (json.detail) {
        // detail may be string or list
        if (typeof json.detail === "string") return json.detail;
        if (Array.isArray(json.detail)) {
          return json.detail
            .map((d) => {
              if (typeof d === "string") return d;
              // pydantic error objects: { loc, msg, type, input }
              if (d.msg) return `${d.loc ? d.loc.join(".") + ": " : ""}${d.msg}`;
              return JSON.stringify(d);
            })
            .join("; ");
        }
      }
      return JSON.stringify(json);
    } catch (e) {
      return "An error occurred";
    }
  };

const handleSubmit = async (e) => {
  e.preventDefault();
  setError("");
  if (!title || !ingredients || !methods || !category) {
    setError("Please fill all required fields.");
    return;
  }

  if (!user?.user_id && !user?.id) {
    setError("Invalid user. Please log in again.");
    return;
  }

  setLoading(true);
  try {
    // send data to backend
    const fd = new FormData();
    fd.append("title", title);
    fd.append("ingredients", ingredients);
    fd.append("methods", methods);
    if (youtube) fd.append("youtube_link", youtube);
    fd.append("category_id", category);
    fd.append("user_id", parseInt(user?.user_id || user?.id));
    if (imageFile) fd.append("image", imageFile);

    const res = await fetch("http://127.0.0.1:8000/recipes", {
      method: "POST",
      body: fd,
    });

    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(readableError(json));
    } else {
      navigate("/");
    }
  } catch (err) {
    console.error("Submit error:", err);
    setError("Network error. Make sure backend is running.");
  } finally {
    setLoading(false);
  }
};

  return (
    <div className="create-recipe-container">
      <h2>Create Recipe</h2>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea placeholder="Ingredients" value={ingredients} onChange={(e) => setIngredients(e.target.value)} />
        <textarea placeholder="Methods" value={methods} onChange={(e) => setMethods(e.target.value)} />
        <input placeholder="YouTube link" value={youtube} onChange={(e) => setYoutube(e.target.value)} />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Select Category</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>

        {/* image file input */}
        <label style={{ marginTop: 8 }}>
          Upload image (optional)
          <input
            type="file"
            accept="image/*"
            onChange={(e) => setImageFile(e.target.files && e.target.files[0])}
            style={{ display: "block", marginTop: 6 }}
          />
        </label>

        <button type="submit">{loading ? "Saving..." : "Create Recipe"}</button>
      </form>
    </div>
  );
}
