// src/user/RecipeDetails.jsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "../css/RecipeDetails.css"; // new css file

export default function RecipeDetails() {
  const { id } = useParams(); // recipe id from URL
  const navigate = useNavigate();
  const [recipe, setRecipe] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    setLoading(true);
    fetch(`http://127.0.0.1:8000/recipes/${id}`)
      .then((res) => {
        if (!res.ok) throw new Error("Recipe not found");
        return res.json();
      })
      .then((data) => {
        setRecipe(data);
      })
      .catch((err) => setError(err.message || "Failed to load recipe"))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <p className="rd-loading">Loading recipe...</p>;
  if (error) return <p className="rd-error">{error}</p>;
  if (!recipe) return null;

  // convert youtube url to embed if possible
  const toEmbed = (url) => {
    if (!url) return null;
    try {
      const u = new URL(url);
      if (u.hostname.includes("youtube.com")) {
        const v = u.searchParams.get("v");
        if (v) return `https://www.youtube.com/embed/${v}`;
      }
      if (u.hostname === "youtu.be") {
        const id = u.pathname.slice(1);
        return `https://www.youtube.com/embed/${id}`;
      }
    } catch (e) {
      return null;
    }
    return null;
  };

  const embedUrl = toEmbed(recipe.youtube_link);

  return (
    <div className="rd-page">
      <div className="rd-wrapper">
        <button className="rd-back" onClick={() => navigate(-1)}>
          ← Back
        </button>

        <article className="rd-card">
          <header className="rd-header">
            <h1 className="rd-title">{recipe.title}</h1>
            <div className="rd-meta">
              <span className="rd-category">{recipe.category_name ?? "Unknown"}</span>
              <span className="rd-author">By {recipe.username ?? recipe.user_id ?? "Unknown"}</span>
            </div>
          </header>

          <section className="rd-section">
            <h2 className="rd-section-title">Ingredients</h2>
            <div className="rd-content">
              <p className="rd-text" style={{ whiteSpace: "pre-wrap" }}>{recipe.ingredients}</p>
            </div>
          </section>

          <section className="rd-section">
            <h2 className="rd-section-title">Method</h2>
            <div className="rd-content">
              <p className="rd-text" style={{ whiteSpace: "pre-wrap" }}>{recipe.methods}</p>
            </div>
          </section>

          {recipe.youtube_link && (
            <section className="rd-section rd-youtube">
              <h2 className="rd-section-title">Video</h2>
              <div className="rd-content rd-video-wrap">
                {embedUrl ? (
                  <iframe
                    title="recipe video"
                    src={embedUrl}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (
                  <a className="rd-link" href={recipe.youtube_link} target="_blank" rel="noreferrer">
                    Watch on YouTube
                  </a>
                )}
              </div>
            </section>
          )}

        </article>
      </div>
    </div>
  );
}
