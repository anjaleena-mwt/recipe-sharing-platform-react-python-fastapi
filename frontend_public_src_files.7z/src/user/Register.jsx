import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../css/Register.css";

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: "", email: "", password: "", confirmpass: "", address: "", phone_number: ""
  });
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const errs = {};
    if (!form.username) errs.username = "Username required";
    if (!form.email) errs.email = "Email required";
    if (!form.password) errs.password = "Password required";
    if (form.password !== form.confirmpass) errs.confirmpass = "Passwords do not match";
    if (!form.address) errs.address = "Address required";
    if (!form.phone_number) errs.phone_number = "Phone number required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setApiError(null);

    try {
      const res = await fetch("http://127.0.0.1:8000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: form.username,
          user_email: form.email,
          password: form.password,
          confirm_password: form.confirmpass,
          address: form.address,
          phone_number: form.phone_number,
        }),
      });
      const json = await res.json().catch(() => ({}));

      if (!res.ok) {
        setApiError(json.detail || "Registration failed");
      } else {
        localStorage.setItem(
          "user",
          JSON.stringify({ username: form.username, user_email: form.email, address: form.address, phone_number: form.phone_number })
        );
        navigate("/login");
      }
    } catch {
      setApiError("Could not reach backend. Start your server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <form id="registerForm" onSubmit={handleSubmit}>
        <h1>REGISTRATION</h1>

        <label>Username:</label>
        <input type="text" name="username" value={form.username} onChange={handleChange} />
        {errors.username && <span className="error">{errors.username}</span>}

        <label>Email:</label>
        <input name="email" value={form.email} onChange={handleChange} />
        {errors.email && <span className="error">{errors.email}</span>}

        <label>Password:</label>
        <input type="password" name="password" value={form.password} onChange={handleChange} />
        {errors.password && <span className="error">{errors.password}</span>}

        <label>Confirm Password:</label>
        <input type="password" name="confirmpass" value={form.confirmpass} onChange={handleChange} />
        {errors.confirmpass && <span className="error">{errors.confirmpass}</span>}

        <label>Address:</label>
        <input type="address" name="address" value={form.address} onChange={handleChange} />
        {errors.address && <span className="error">{errors.address}</span>}

        <label>Phone Number:</label>
        <input name="phone_number" value={form.phone_number} onChange={handleChange} />
        {errors.phone_number && <span className="error">{errors.phone_number}</span>}

        {apiError && <div className="error">{apiError}</div>}

        <input type="submit" value={loading ? "Submitting..." : "SUBMIT"} />

        <div>
          Already registered? <a href="/login">Login</a>
        </div>
      </form>
    </div>
  );
}
