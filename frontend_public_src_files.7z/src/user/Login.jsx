import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../css/Login.css";

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!email || !password) {
      setError("Please enter both email and password.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("http://127.0.0.1:8000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_email: email, password }),
      });

      // parse JSON safely
      const json = await res.json().catch(() => ({}));
      console.log("Login response:", res.status, json);

      if (!res.ok) {
  setError(json.detail || "Login failed. Check credentials.");
} else {
  // Save whatever backend returned. Profile expects keys like username, user_email, user_id.
  const userObj = { ...json, is_admin: json.is_admin ?? false };
  localStorage.setItem("user", JSON.stringify(userObj));
  // navigate to profile and replace history so back button doesn't show login
  navigate("/profile", { replace: true });
}
    } catch (err) {
      console.error("Login error:", err);
      setError("Could not reach backend. Start your server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <form id="loginForm" onSubmit={handleSubmit}>
        <h1>LOGIN</h1>

        <label>Email:</label>
        <input
          type="text"
          placeholder="username@gmail.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <label>Password:</label>
        <input
          type="password"
          placeholder="Use Strong Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {error && <p className="error">{error}</p>}

        <input type="submit" value={loading ? "Logging in..." : "SUBMIT"} />

        <div>
          New User? <a href="/register">Register</a>
        </div>
      </form>
    </div>
  );
}

export default Login;
