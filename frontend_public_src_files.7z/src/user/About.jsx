import React from "react";
import "../css/About.css";

function About() {
  return (
    <div>
      <h3>
        <b>ABOUT RECIPE REALM</b>
      </h3>
      <div className="about-container">
        <p>
          Welcome to <strong>Recipe Realm</strong>, your ultimate destination for
          sharing and discovering delicious recipes from around the world! Here,
          passionate home cooks and food lovers come together to create, post,
          and explore a wide variety of dishes.
        </p>
        <p>
          Whether you're looking to try something new or share your own kitchen
          masterpieces, Recipe Realm makes it simple — just log in, upload your
          recipe with ingredients, methods, and even YouTube videos, and inspire
          others.
        </p>
        <p>
          Search, browse, and enjoy recipes approved by our admin team, ensuring
          quality and authenticity in every dish.
        </p>
        <p>
          Join the Realm of Recipes today and make cooking a shared adventure! 🍳✨
        </p>
      </div>
    </div>
  );
}

export default About;
